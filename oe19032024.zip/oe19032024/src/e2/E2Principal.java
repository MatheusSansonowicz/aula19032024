package e2;

import java.util.Scanner;

public class E2Principal {

	public static void main(String[] args) {
		
		/*Essa classe Computador também deverá ser executável, entretanto crie uma outra classe
		executável que irá instanciar a classe Computador, criando 2 objetos.
		O primeiro objeto deverá ser criado através da solicitação dos valores ao usuário
		 por linha de execução. Já, os valores do
		segundo objeto, deverão ser definidos no código-fonte da classe que o criou.
		 Exiba na tela os resultados.*/
		
		Scanner teclado = new Scanner(System.in);
		
		Computador PC1 = new Computador();
		
		System.out.println("Digite a marca do computador 1: ");
		PC1.marca = teclado.nextLine();
		teclado.nextLine();
		System.out.println("Digite o modelo do computador 1: ");
		PC1.modelo = teclado.nextLine();
		teclado.nextLine();
		System.out.println("Digite o tipo do computador 1: ");
		PC1.tipo = teclado.nextLine();
		teclado.nextLine();
		System.out.println("Digite o preco do computador 1: ");
		PC1.preco = teclado.nextDouble();
		
		Computador PC2 = new Computador();
		PC2.marca = "samsung";
		PC2.modelo = "I7 11º geração";
		PC2.tipo = "de mesa";
		PC2.preco = 1143.32;
		
		System.out.println("Dados computador 1: " +PC1.marca +" " +PC1.modelo +" " +PC1.tipo +" e vale " +PC1.preco);
		System.out.println("Dados computador 2: " +PC2.marca +" " +PC2.modelo +" " +PC2.tipo +" e vale " +PC2.preco);
	}

}

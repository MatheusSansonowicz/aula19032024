package e2;

public class Computador {
	
	//2 - Crie uma classe chama Computador que possua 4 atributos: marca, modelo, tipo (notebook,
	//netbook, tablet, etc) e preço.
	
	public String marca;
	public String modelo;
	public String tipo;
	public double preco;

}

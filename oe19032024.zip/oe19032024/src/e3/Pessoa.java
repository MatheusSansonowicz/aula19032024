package e3;

public class Pessoa {
	
	public String nome;
	public int idade;
	public String genero;

}

package e3;

public class E3principal {

	public static void main(String[] args) {
		
		//3 - Crie uma classe Pessoa com os atributos nome, idade e gênero. Imprima
		//as informações da pessoa na tela.
		
		Pessoa Pessoa1 = new Pessoa();
		Pessoa1.nome = "Matheus";
		Pessoa1.idade = 19;
		Pessoa1.genero ="Masculino";
		System.out.println("O nome é " +Pessoa1.nome +" Tem " +Pessoa1.idade +" e é do genero " +Pessoa1.genero);

	}

}

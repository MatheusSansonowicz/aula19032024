package e4;

import e3.Pessoa;

public class E4Principal {
	
	public static void main(String[] args) {
		
		//4 - Crie uma classe Livro com os atributos título, autor e ano de publicação.
		//Imprima as informações do livro na tela
		
		Livro LivroNovo = new Livro();
		LivroNovo.Titulo = "Harry Potter";
		LivroNovo.Autor	= "JK Rouling";
		LivroNovo.anoPub = "1990";
		
		System.out.println("O livro " +LivroNovo.Titulo +" Da autora " +LivroNovo.Autor +" foi publucadi em " +LivroNovo.anoPub);
	}

}

package e4;

public class Livro {
	
	public String Titulo;
	public String Autor;
	public String anoPub;

}

package e1;

import java.util.Scanner;

public class E1geral {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		
		//1 - Crie uma classe chamada Carro que possua 3 atributos: marca, modelo e anoFabricacao.
		//Além disso, crie uma classe executável para criar 2 objetos do tipo Carro
		//e exibir na tela os valores dos atributos criados.
		
		Carro carro1 = new Carro();
		
		Carro carro2 = new Carro();
		
		System.out.println("Digite a marca do carro 1: ");
		carro1.marca = teclado.nextLine();
		teclado.nextLine();
		System.out.println("Digite o modelo do carro 1: ");
		carro1.modelo = teclado.nextLine();
		teclado.nextLine();
		System.out.println("Digite o ano de fabricacao do carro 1: ");
		carro1.anoFabricado = teclado.nextLine();
		teclado.nextLine();
		
		System.out.println("Digite a marca do carro 2: ");
		carro2.marca = teclado.nextLine();
		teclado.nextLine();
		System.out.println("Digite o modelo do carro 2: ");
		carro2.modelo = teclado.nextLine();
		teclado.nextLine();
		System.out.println("Digite o ano de fabricacao do carro 2: ");
		carro2.anoFabricado = teclado.nextLine();
		teclado.nextLine();
		
		System.out.println("O carro eh é um " +carro1.modelo +" da " + carro1.marca +" fabricado em " +carro1.anoFabricado);
		
		System.out.println("O carro 2 eh um " +carro2.modelo +" da " + carro2.marca +" fabricado em " +carro2.anoFabricado);


	}

}

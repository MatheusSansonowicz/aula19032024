package e1;

public class Carro {
	
	public String marca;
	
	public String modelo;
	
	public String anoFabricado;

}

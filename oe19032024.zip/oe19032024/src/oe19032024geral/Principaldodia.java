package oe19032024geral;

import java.util.Scanner;

public class Principaldodia {
	
	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		Pessoa p1 = new Pessoa ();
		
		
		/*p1.nome = "João";
		p2.nome = "Maria";
		p1.idade = 23;
		p2.idade = 19;
		p3.idade = 10;*/
		System.out.println("Digite o nome da pessoa 1: ");
		p1.nome = teclado.nextLine();
		System.out.println("Digite a idade da pessoa 1: ");
		p1.idade = teclado.nextInt();
		teclado.nextLine();
		
		Pessoa p2 = new Pessoa ();
		System.out.println("Digite o nome da pessoa 2: ");
		p2.nome = teclado.nextLine();
		System.out.println("Digite a idade da pessoa 2: ");
		p2.idade = teclado.nextInt();
		teclado.nextLine();
		
		Pessoa p3 = new Pessoa ();
		System.out.println("Digite o nome da pessoa 3: ");
		p3.nome = teclado.nextLine();
		System.out.println("Digite a idade da pessoa 3: ");
		p3.idade = teclado.nextInt();
		teclado.nextLine();
		
		//System.out.println("A pessoa foi instanciada");
		//System.out.println("A pessoa 1 tem nome " +p1.nome);
		//System.out.println("A pessoa 2 tem nome " +p2.nome);
		
		System.out.println(p1.nome +" Tem " +p1.idade +" idade");
		System.out.println(p2.nome +" Tem " +p2.idade +" idade");
		System.out.println(p3 .nome +" Tem " +p3.idade +" idade");

	}

}


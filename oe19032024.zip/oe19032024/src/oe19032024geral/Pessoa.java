package oe19032024geral;

public class Pessoa {
	
	public String nome;
	public int idade;

}

package oe19032024geral;

public class Professor {
	
	public String nome;

}

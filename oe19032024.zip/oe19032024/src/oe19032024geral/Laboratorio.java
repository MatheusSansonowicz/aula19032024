package oe19032024geral;

public class Laboratorio {
	
	public String local;

}

package oe19032024geral;

import java.util.Scanner;

public class Disciplina {
	
	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
	
		Professor NovoProf = new Professor();
		
		Laboratorio NovaSala = new Laboratorio() ;
		
		/*Ricardo.nome = "Ricardo da Silva";
		
		Sala108.local = "Prédio 3, conjunto 1, Sala 108";*/
		
		System.out.println("Digite o nome do professor: ");
		NovoProf.nome = teclado.nextLine();
		
		
		System.out.println("Diga a sala: ");
		NovaSala.local = teclado.nextLine();
				
		System.out.println("O nome do professor é: " +NovoProf.nome);
		
		System.out.println("O local da sala é: " +NovaSala.local);
	}

}
